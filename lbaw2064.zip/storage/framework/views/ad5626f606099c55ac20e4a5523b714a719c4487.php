<h2 class="mt-0">Comments</h2>

<div class="media-body">
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="comment">
        <p>
            <a href="profile.php" class="username"><?php echo e($userComments[$comment->id]->username); ?> </a>
            <a class="icon-answers" href="#">
                <i class="fas fa-bug"> Report</i>
            </a>
            <br>
            <?php echo e($comment->content); ?>

        </p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>  <?php /**PATH /Users/pedrodantas/Desktop/FEUP/3ano/LBAW/lbaw2064/resources/views/partials/comments.blade.php ENDPATH**/ ?>