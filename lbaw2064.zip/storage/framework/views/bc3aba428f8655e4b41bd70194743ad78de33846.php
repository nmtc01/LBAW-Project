<?php $__env->startSection('css_script'); ?>
    ##parent-placeholder-d7baa116431a7eeabca427472a6a759c03a72b60##
    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container register">
  <div class="row">
  
    <div class="col-md-3 register-left my-auto">
        <h1><a href="">Answerly</a></h1>
        <p>Hope you have a lot of questions ready to be answered!</p>
    </div>

    <div class="col-md-9 register-right">

        <div class="tab-content" id="myTabContent">

            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

              <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>


              <div class="row register-form">

                  <div class="col-md-6">
              
                    <div class="form-group">
                      <input id="first_name" class="form-control" placeholder="First Name *" type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" required autofocus>
                      <?php if($errors->has('first_name')): ?>
                        <span class="error">
                            <?php echo e($errors->first('first_name')); ?>

                        </span>
                      <?php endif; ?>
                    </div>

                    <div class="form-group">
                      <input id="last_name" class="form-control" placeholder="Last Name *" type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" required autofocus>
                      <?php if($errors->has('last_name')): ?>
                        <span class="error">
                            <?php echo e($errors->first('last_name')); ?>

                        </span>
                      <?php endif; ?>
                    </div>

                    <div class="form-group">
                      <input id="email" class="form-control" placeholder="Your Email *" type="text" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                      <?php if($errors->has('email')): ?>
                        <span class="error">
                            <?php echo e($errors->first('email')); ?>

                        </span>
                      <?php endif; ?>
                    </div>


                    <div class="form-group">
                      <div class="maxl">
                          <label class="radio inline">
                              <input type="radio" name="gender" value="male" checked>
                              <span> Male </span>
                          </label>
                          <label class="radio inline">
                              <input type="radio" name="gender" value="female">
                              <span>Female </span>
                          </label>
                      </div>
                    </div>

                  </div>
                  <div class="col-md-6 ml-auto">

                    <div class="form-group">
                      <input id="username" class="form-control" placeholder="Username *" type="text" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
                      <?php if($errors->has('username')): ?>
                        <span class="error">
                            <?php echo e($errors->first('username')); ?>

                        </span>
                      <?php endif; ?>
                    </div>

                    <div class="form-group">
                      <input id="password" type="password" class="form-control" placeholder="Password *" name="password" required>
                      <?php if($errors->has('password')): ?>
                        <span class="error">
                            <?php echo e($errors->first('password')); ?>

                        </span>
                      <?php endif; ?>
                    </div>

                    <div class="form-group">
                      <input id="password-confirm" type="password" class="form-control" placeholder="Confirm Password *" name="password_confirmation" required>
                    </div>

                    <div class="form-group">
                      <textarea class="form-control" placeholder="Description" name="bio" value="" rows="5"></textarea>
                      <?php if($errors->has('bio')): ?>
                        <span class="error">
                            <?php echo e($errors->first('bio')); ?>

                        </span>
                      <?php endif; ?>
                    </div>
                  </div>
              </div>
              <div class="col-md-6 ml-auto">   
                <input type="submit" id="register_button" class="btnRegister" value="Register" />
                
                <div class="align-middle d-flex justify-content-end">
                  <a class="d-flex justify-content-end" href="<?php echo e(route('login')); ?>">Sign In</a>
                </div>

              </div>
              </form>      
            </div>
        </div>
    </div> 
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pedrodantas/Desktop/FEUP/3ano/LBAW/lbaw2064/resources/views/auth/register.blade.php ENDPATH**/ ?>