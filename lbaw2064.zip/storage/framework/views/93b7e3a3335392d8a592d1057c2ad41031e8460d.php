<?php $__env->startSection('css_script'); ?>
    ##parent-placeholder-d7baa116431a7eeabca427472a6a759c03a72b60##
    <link rel="stylesheet" href="<?php echo e(asset('css/about.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="about">
        <h1>Error 404</h1>
        <p>We are sorry.</p>
        <p>The page you are looking for cannot be found.</p>
        <p>Please go back to our home page or try to find what you are looking for by using our search bar.</p>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pedrodantas/Desktop/FEUP/3ano/LBAW/lbaw2064/resources/views/errors/404.blade.php ENDPATH**/ ?>