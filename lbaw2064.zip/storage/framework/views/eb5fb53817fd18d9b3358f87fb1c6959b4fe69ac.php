<?php $__env->startSection('css_script'); ?>
    ##parent-placeholder-d7baa116431a7eeabca427472a6a759c03a72b60##
    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container register">
    <div class="row">

        <div class="col-md-3 register-left my-auto">
            <h1><a href="<?php echo e(url('/')); ?>">Answerly</a></h1>
            <p>Hope you have a lot of questions ready to be answered!</p>
        </div>

        <div class="col-md-9 register-right">
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

                <div class="row register-form">

                        <div class="col-md-6 ml-auto">
                                    
                            
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo e(csrf_field()); ?>

                        
                                <div class="form-group">
                                    <input id="username" type="username" class="form-control" name="username" placeholder="Username *" value="<?php echo e(old('username')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('username')): ?>
                                    <span class="error">
                                        <?php echo e($errors->first('username')); ?>

                                    </span>
                                <?php endif; ?>
                            
                                <div class="form-group">
                                    <input id="password" type="password" class="form-control" name="password" placeholder="Passord *" required>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="error">
                                        <?php echo e($errors->first('password')); ?>

                                    </span>
                                <?php endif; ?>

                                <div class="form-group">
                                    <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                </div>

                                <input type="submit" id="login_button" class="btnRegister" value="Login">
                            
                                <div class="align-middle d-flex justify-content-end">
                                    
                                    <a class="button button-outline" href="<?php echo e(route('register')); ?>">Create account</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pedrodantas/Desktop/FEUP/3ano/LBAW/lbaw2064/resources/views/auth/login.blade.php ENDPATH**/ ?>