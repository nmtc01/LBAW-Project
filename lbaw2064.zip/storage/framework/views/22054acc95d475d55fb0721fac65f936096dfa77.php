<h2 class="mt-0">Answers</h2>
            
<ul class="list-unstyled" id="answers-list">
    <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li id="answer" data-id = "<?php echo e($answer->id); ?>">
        <div class="row">
            <a class="col-sm-3 d-none d-sm-block text-center" href="../pages/profile.php">
                <img src="<?php echo e(asset('img/unknown.png')); ?>" alt="Generic placeholder image">
            </a>
            <div class="col-sm-9">
                <span class="badge badge-success"><i class="fas fa-star"></i>Score <?php echo e($userAnswers[$answer->id]->score); ?></span>
                <p id="user_ans"><a href="../pages/profile.php"><?php echo e($userAnswers[$answer->id]->username); ?></a></p>
            </div>
        </div>
        <div class="ans-body">
            <p><?php echo e($answer->content); ?></p>
            <div class=icons-answers>
                <a class="icon-answers" href="#">
                    <i class="fas fa-thumbs-up"><?php echo e($answer->nr_likes); ?></i>
                </a>
                <a class="icon-answers" href="#">
                    <i class="fas fa-thumbs-down"><?php echo e($answer->nr_dislikes); ?></i>
                </a>
                <a class="icon-answers" href="#">
                    <i class="fas fa-comment">0</i>
                </a>
                <a class="icon-answers" href="#">
                    <i class="fas fa-bug"> Report</i>
                </a>
                <?php if(Auth::check() && Auth::user()->id == $answer->user_id): ?>
                <a class="icon-answers" id="delete">
                    <i class="fas fa-trash-alt"></i>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /Users/pedrodantas/Desktop/FEUP/3ano/LBAW/lbaw2064/resources/views/partials/answers.blade.php ENDPATH**/ ?>