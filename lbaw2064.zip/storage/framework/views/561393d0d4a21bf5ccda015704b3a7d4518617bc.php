<?php $__env->startSection('css_script'); ?>
    ##parent-placeholder-d7baa116431a7eeabca427472a6a759c03a72b60##
    <link rel="stylesheet" href="<?php echo e(asset('css/question.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="question-div" class="container-fluid" data-id = "<?php echo e($question->id); ?>">
    <div class="wrapper col-md-5">
        <?php echo $__env->make('partials.question', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <div class="form-group">
                <label for="exampleFormControlTextarea1"></label>
                <!--<textarea class="form-control" placeholder="Do you know the answer to this question?"id="exampleFormControlTextarea1" rows="4"></textarea>-->
                <form class="new_answer">
                    <!--<input type="text" class="form-control" id="exampleFormControlTextarea1" name="answer" placeholder="Do you know the answer to this question?">-->
                    <textarea class="form-control" placeholder="Do you know the answer to this question?"id="exampleFormControlTextarea1" rows="4"></textarea>
                </form>
                <button class="btn my-2 my-sm-0" type="submit">Answer</button>
            </div>

            <div class="form-group">
                <label for="exampleFormControlTextarea1"></label>
                <textarea class="form-control" placeholder="Do you want to comment this question?"id="exampleFormControlTextarea1" rows="2"></textarea>
                <button class="btn my-2 my-sm-0" type="submit">Comment</button>
            </div>

            <?php echo $__env->make('partials.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>              
            <?php echo $__env->make('partials.answers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pedrodantas/Desktop/FEUP/3ano/LBAW/lbaw2064/resources/views/pages/question_page.blade.php ENDPATH**/ ?>