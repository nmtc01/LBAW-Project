<div class="col-md-5 container-fluid">
    <button id="add_btn" class="input-button" data-toggle="modal" data-target="#ask_something">
        What is your question?
    </button>

    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="wrapper home_question container-fluid">
            <div class="row">
                <div id="prof_info" class="col-2 text-center">
                    <img src="<?php echo e(asset('/img/unknown.png')); ?>">
                    <p><a class="row-2 d-none d-sm-block" href="/pages/profile.php"><?php echo e($users[$question->id]->username); ?></a></p>
                </div>
                <div class="col-10">
                    <h1><a id="question-header" href="<?php echo e(asset('question/'.$question->id)); ?>"><?php echo e($question->title); ?></a></h1>
                </div>
            </div>

            <div class="icons">
                <a class="icon" href="#">
                <i class="fas fa-thumbs-up fa-lg"> <?php echo e($question->nr_likes); ?></i>
                </a>
                <a class="icon" href="#">
                    <i class="fas fa-thumbs-down fa-lg"> <?php echo e($question->nr_dislikes); ?></i>
                </a>
                <a class="icon" href="#">
                    <i class="fas fa-reply fa-lg"> 10 </i>
                </a>

                <?php if(Auth::check()): ?>
                <a class="icon" href="#">
                    <i class="fas fa-arrow-right fa-lg"> follow</i>
                </a>
                <?php endif; ?>
                <p class="icon" id=question_date><?php echo e($question->question_date); ?></p>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH /Users/pedrodantas/Desktop/FEUP/3ano/LBAW/lbaw2064/resources/views/partials/home_questions.blade.php ENDPATH**/ ?>