<?php $__env->startSection('css_script'); ?>
    ##parent-placeholder-d7baa116431a7eeabca427472a6a759c03a72b60##
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('partials.home_questions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/pedrodantas/Desktop/FEUP/3ano/LBAW/lbaw2064/resources/views/pages/home.blade.php ENDPATH**/ ?>